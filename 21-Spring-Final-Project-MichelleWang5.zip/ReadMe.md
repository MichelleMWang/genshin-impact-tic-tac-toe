You will choose which program you want to write from the list below or get your own idea pre-approved by me.  No one is allowed to make a calculator though.

Include short and easy to understand directions along with an easy UI as I will be demoing those and there is only a couple minutes available for each one.

Having it due in at the end of May may seem like a lot of time, but with 3 weeks of APs for some of you, the time will fly.  You NEED to be working diligently on this every day during our class time or as homework (an hour twice a week) so that you can avoid a miserable few nights during the last week before it is due. 

The better the program looks, the easier it is to use, and the more functionality you put into it will increase your grade.  I would recommend taking a simpler concept and doing it well as opposed to a hard concept and doing it poorly.  If you want to take your first semester final project and improve on it, that is a valid choice.  Most of those would be improved greatly with arrays or lists and a GUI.

You will be submitting a zip file with your code and any assets (images or sound if you go that route) as well as a link to your repl.

Applications:
+ Grade Book Application (from student perspective).
+ Slide Show – Make an application that shows pictures in a folder in a slide show format. You will add various effects like fade in/out, star wipe and window blinds transitions (Remember picture lab?  It has prepared you for this).  You will add options to go in order or go randomly.  This requires you to research a little file input and output.
+ Mind Mapper – Allow the user to put down ideas and quickly brainstorm how they are related into a mind map. The goal here is speed so let the user quickly write in an idea and drag it around in a visual map to show relationships.
+ To do list - One of the typical beginning programs.  Should have a way to check things off, reorder the items, etc.

Games (All 2 player games assume 2 human players):
+ Hangman
+ Craps
+ Memory
+ Tic Tac Toe
+ Slide Puzzle
+ Sokoba
+ Checkers
+ Chess
+ Frogger
+ Battleship
+ Yahtzee
+ Sudoku
+ Card games (Poker, Solitare, etc.)
+ Ultimate Tic Tac Toe
+ Minesweeper
+ Text adventure games like Zork

Some other games from previous years:
+ I love hue
+ first person (water pistol) shooter
+ A starting pass at Minecraft with good physics and lighting
+ Checkers with an AI no one can beat
+ Adventure
+ Platform games (like Super Mario Bros)


Directions for zipping your final project:

In REPL click on the 3 vertical dots in the files area and then Download as zip.