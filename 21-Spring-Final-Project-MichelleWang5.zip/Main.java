import java.awt.Dimension;
import java.io.IOException;

import javax.swing.JFrame;

public class Main {
	private static final int WIDTH = 500; 
	private static final int HEIGHT = 600;

	  public static void main(String[] args) throws IOException{
		  JFrame frame = new JFrame("Tic Tac Toe"); 
		  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  Intro intro = new Intro(); 
		  String[] characters = intro.getIntro();  
		  if (characters[0] != null) {
		  Game game = new Game(characters);  
		  game.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		  frame.add(game.getGUI());
		  frame.pack(); 
		  frame.setVisible(true); 
		  } else {
			  System.out.println("Exited Intro Window"); 
		  }
	  }
	 
}

