import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class Intro {
	private String[] chosenChars; 
	public Intro() {
		chosenChars = new String[2]; 
	}
	public String[] getIntro() {
		JPanel start = new JPanel(new GridBagLayout()); 
		GridBagConstraints c = new GridBagConstraints(); 
		JLabel choose = new JLabel("Choose Your Character: ");
		choose.setForeground(Color.GREEN);//text color to make it stand out more 
		c.gridx = 0; 
		c.gridy = 1; 
		start.add(choose, c);
		JLabel p1 = new JLabel("Player 1");
		p1.setForeground(Color.GREEN);
		c.gridx = 1; 
		start.add(p1, c);
		JLabel p2 = new JLabel("Player 2"); 
		p2.setForeground(Color.GREEN);
		c.gridx = 2; 
		start.add(p2, c);
		
		JRadioButton dilucButton1 = new JRadioButton("Diluc");//character choices for player 1 as JRadioButtons in a group (so can only pick 1) 
		dilucButton1.setActionCommand("diluc"); //so can tell which button they choose: can get this value using method after optionpane is closed
		JRadioButton kaeyaButton1 = new JRadioButton("Kaeya"); 
		kaeyaButton1.setActionCommand("kaeya"); 
		JRadioButton barbaraButton1 = new JRadioButton("Barbara"); 
		barbaraButton1.setActionCommand("barbara"); 
		JRadioButton ganyuButton1 = new JRadioButton("Ganyu"); 
		ganyuButton1.setActionCommand("ganyu"); 
		ButtonGroup player1Choices = new ButtonGroup(); //so only can pick 1 character
		player1Choices.add(dilucButton1);
		player1Choices.add(kaeyaButton1);
		player1Choices.add(barbaraButton1);
		player1Choices.add(ganyuButton1);

		c.gridx = 1; 
		c.gridy = 2; 
		start.add(dilucButton1, c);
		c.gridy = 3;
		start.add(kaeyaButton1, c);
		c.gridy = 4;
		start.add(barbaraButton1, c);
		c.gridy = 5;
		start.add(ganyuButton1, c);
		
		JRadioButton dilucButton2 = new JRadioButton("Diluc"); 
		dilucButton2.setActionCommand("diluc");
		JRadioButton kaeyaButton2 = new JRadioButton("Kaeya"); 
		kaeyaButton2.setActionCommand("kaeya"); 
		JRadioButton barbaraButton2 = new JRadioButton("Barbara"); 
		barbaraButton2.setActionCommand("barbara");  
		JRadioButton ganyuButton2 = new JRadioButton("Ganyu"); 
		ganyuButton2.setActionCommand("ganyu");
		
		ButtonGroup player2Choices = new ButtonGroup(); 
		player2Choices.add(dilucButton2);
		player2Choices.add(kaeyaButton2);
		player2Choices.add(barbaraButton2);
		player2Choices.add(ganyuButton2);
    //layout stuff for character choices 
		c.gridx = 2; 
		c.gridy = 2; 
		start.add(dilucButton2, c);
		c.gridy = 3;
		start.add(kaeyaButton2, c);
		c.gridy = 4;
		start.add(barbaraButton2, c);
		c.gridy = 5;
		start.add(ganyuButton2, c);
		//show picture for each character corresponding to radio button choices 
		JLabel dilucPic = new JLabel(new ImageIcon("diluc.jpg")); 
		c.gridx = 0; 
		c.gridy = 2; 
		start.add(dilucPic, c); 
		JLabel kaeyaPic = new JLabel(new ImageIcon("kaeya.png")); 
		c.gridy = 3; 
		start.add(kaeyaPic, c); 
		JLabel barbaraPic = new JLabel(new ImageIcon("barbara.png")); 
		c.gridy = 4; 
		start.add(barbaraPic, c); 
		JLabel ganyuPic = new JLabel(new ImageIcon("ganyu.png")); 
		c.gridy = 5; 
		start.add(ganyuPic, c); 
		JLabel rules = new JLabel("<html> Welcome to Tic Tac Toe! <br/>"
				+ "1. The game is played on a 3x3 grid with squares called territories. <br/>"
				+ "2. Players take turns claiming territories by clicking on the empty squares. <br/>"
				+ "3. The 1st player to get 3 territories in a row (up/down, across, diagonal) wins. <br/>"
				+ "4. If no player has 3 in a row and there are no more spaces, it's a draw. <br/><html>");  
		c.fill = GridBagConstraints.HORIZONTAL;  
		c.gridwidth = 3; //spans 3 columns (the entire panel)
		c.gridx = 0;
		c.gridy = 0; 
		start.add(rules, c); 
		Object[] options = {"Start Game!"};
	    int n = JOptionPane.showOptionDialog(null,
			start,
			"Rules",
			JOptionPane.PLAIN_MESSAGE, JOptionPane.QUESTION_MESSAGE, null, options, options[0]); 
	    if (JOptionPane.OK_OPTION == n) {
	    	chosenChars[0] = player1Choices.getSelection().getActionCommand(); 
	    	chosenChars[1] = player2Choices.getSelection().getActionCommand();
	    	return chosenChars;  //string[] with character choices: returned bc need this data for the game class 
	    } else {
	    	return chosenChars; //will have nulls (accounted for in Main)
	    }
	}
}
