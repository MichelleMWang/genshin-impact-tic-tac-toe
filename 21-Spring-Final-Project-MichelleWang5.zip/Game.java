import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Game extends JComponent{
	private int p1Score; 
	private int p2Score; 
	private int numTurns;
	private final int NUM_COLS = 3; 
	private final int NUM_ROWS = 3; 
	private JButton[][] boxes; 
	private String[][] board; 
	private Icon X; 
	private Icon O; 
	private Icon draw; 
	private JPanel panel; 
	private File p1Turn; 
	private File p1Win; 
	private File p2Turn; 
	private File p2Win;  
	private JLabel turnImage; 
  private JLabel scores; 
	
public Game(String[] chara) throws IOException{
		board = new String[NUM_ROWS][NUM_COLS]; 
		draw = new ImageIcon("draw.jpg"); //image for draw (tie) 
		playSound(new File("silent.wav")); //to minimize lag for first sound - executing compiled code before it is needed bc it lags kinda bad otherwise 
		p1Score = 0; 
		p2Score = 0; 
		numTurns = 0; 
    //initializing the variables based on which characters chosen for p1 and p2 
		if (chara[0].equals("diluc")) {
			p1Turn = new File("dilucturn.wav"); 
			p1Win = new File("dilucwin.wav"); 
			X = new ImageIcon("diluc.jpg"); 
		} else if (chara[0].equals("kaeya")) {
			p1Turn = new File("kaeyaturn.wav"); 
			p1Win = new File("kaeyawin.wav"); 
			X = new ImageIcon("kaeya.png");
		} else if (chara[0].equals("barbara")) {
			p1Turn = new File("barbaraturn.wav"); 
			p1Win = new File("barbarawin.wav"); 
			X = new ImageIcon("barbara.png");
		} else if (chara[0].equals("ganyu")) {
			p1Turn = new File("ganyuturn.wav"); 
			p1Win = new File("ganyuwin.wav"); 
			X = new ImageIcon("ganyu.png");
		}
		
		if (chara[1].equals("diluc")) {
			p2Turn = new File("dilucturn.wav"); 
			p2Win = new File("dilucwin.wav"); 
			O = new ImageIcon("diluc.jpg"); 
		} else if (chara[1].equals("kaeya")) {
			p2Turn = new File("kaeyaturn.wav"); 
			p2Win = new File("kaeyawin.wav"); 
			O = new ImageIcon("kaeya.png");
		} else if (chara[1].equals("barbara")) {
			p2Turn = new File("barbaraturn.wav"); 
			p2Win = new File("barbarawin.wav"); 
			O = new ImageIcon("barbara.png");
		} else if (chara[1].equals("ganyu")) {
			p2Turn = new File("ganyuturn.wav"); 
			p2Win = new File("ganyuwin.wav"); 
			O = new ImageIcon("ganyu.png");
		}

		//layout
		GridLayout layout = new GridLayout(4, 3); //4 rows bc 3x3 board + row to display info (whos turn it is) 
		panel = new JPanel(); 
		panel.setLayout(layout);
 
		boxes = new JButton[3][3]; 
		for (int i = 0; i < NUM_ROWS; i++) { 
			for (int j = 0; j < NUM_COLS; j++) {
			boxes[i][j] = new JButton("");
			boxes[i][j].setIcon(new ImageIcon("blanksquare.png")); //blank white square (to cover the default swing button + to make it look like the heads appear (and not the white background too)
			boxes[i][j].setPreferredSize(new Dimension(WIDTH/3, HEIGHT/3));
			panel.add(boxes[i][j]); 
			board[i][j] = ""; 
			}
		}
		JLabel whosTurn = new JLabel("Who's Turn: ", JLabel.CENTER); 	
		turnImage = new JLabel();  
		if (numTurns % 2 == 0) { turnImage.setIcon(X); }
		else {
			turnImage.setIcon(O); }
    scores = new JLabel("<html> Scoreboard <br/><br/> Player 1: " + p1Score + "<br/>" + " Player 2: "+ p2Score + "<html>", JLabel.CENTER);
    //html tags to make new line in jlabel
		panel.add(whosTurn); 
		panel.add(turnImage);
		panel.add(scores); 
		for (int i = 0; i < NUM_ROWS; i++) {
			for (int j = 0; j < NUM_COLS; j++) {				
				getTurn(i, j);	
			}
		}	
	}

private void getTurn(int ii, int jj) {
	boxes[ii][jj].addActionListener(new ActionListener(){
		@Override 
		public void actionPerformed(ActionEvent e) {		
			if (numTurns % 2 == 0) { //even # turns = X turn, odd = O turn
				if (board[ii][jj].equals("")) { //only count as turn if space clicked is empty 
				playSound(p1Turn); 
				boxes[ii][jj].setIcon(X); 
				board[ii][jj] = "X"; 
				numTurns++; 
				if (checkWin("X", ii, jj)){ //if X won, show win message and option to reset, update scores
					playSound(p1Win); 
					Object[] options = {"Reset board"};
					int n = JOptionPane.showOptionDialog(null,
							"Player 1 Won!",
							"Game Over",
							JOptionPane.DEFAULT_OPTION,
							JOptionPane.QUESTION_MESSAGE, X, options, options[0]); 
							
					if(n == JOptionPane.OK_OPTION) {
						reset();
					}
          p1Score++; 
          scores.setText("<html> Scoreboard <br/><br/> Player 1: " + p1Score + "<br/>" + " Player 2: "+ p2Score + "<html>"); //update scoreboard
				} 
				turnImage.setIcon(O); //Os turn after X. change right after X's turn ends (so it is accurate/useful)
				} 
			}		
			else {
				if (board[ii][jj].equals("")) {	
				playSound(p2Turn); 
				boxes[ii][jj].setIcon(O); 
				board[ii][jj] = "O";
				numTurns++; 
				if (checkWin("O", ii, jj)) {	
					playSound(p2Win); 
					Object[] options = {"Reset board"};
					int n = JOptionPane.showOptionDialog(null,
							"Player 2 won!",
							"Game Over",
							JOptionPane.DEFAULT_OPTION,
							JOptionPane.QUESTION_MESSAGE, O, options, options[0]); 
							
					if(n == JOptionPane.OK_OPTION) {
						reset();
					}
          p2Score++; 
          scores.setText("<html> Scoreboard <br/><br/> Player 1: " + p1Score + "<br/>" + " Player 2: "+ p2Score + "<html>"); //updates scoreboard b/c p2 won 
					
				}
				turnImage.setIcon(X); //to change the "whos turn" part. has to change after the button is clicked to be accurate/useful
				} //if not empty, nothing happens. doesnt let you do anything unless empty space 
			} 
			if (checkDraw()) {
				Object[] options = {"Reset board"};
				int n = JOptionPane.showOptionDialog(null,
						"It was a draw!",
						"Game Over",
						JOptionPane.DEFAULT_OPTION,
						JOptionPane.QUESTION_MESSAGE, draw, options, options[0]); 
				if(n == JOptionPane.OK_OPTION) {
					reset();
				}
			} 
       
		}	
   
	}); 
	}

	private boolean checkWin(String curr, int currRow, int currCol) { 
		   return (board[currRow][0] == curr   //checking for all possibilities      
		            	   && board[currRow][1] == curr
		                   && board[currRow][2] == curr
		                   || board[0][currCol] == curr   
		                   && board[1][currCol] == curr
		                   && board[2][currCol] == curr
		              || currRow == currCol            
		                   && board[0][0] == curr
		                   && board[1][1] == curr
		                   && board[2][2] == curr
		              || currRow + currCol == 2 
		                   && board[0][2] == curr
		                   && board[1][1] == curr
		                   && board[2][0] == curr);
		   }
	private boolean checkDraw() { //if no "" in array (all are filled with X or O)  
	      for (int i = 0; i < NUM_ROWS; i++) {
	         for (int j = 0; j < NUM_COLS; j++) {
	            if (board[i][j].equals("")) {
	               return false; 
	            }
	         }
	      }
	      return true;
	   }
	private void reset() { //not reset numTurns so that the turns leave where they left off
		for (int i = 0; i < NUM_ROWS; i++) {
			for (int j = 0; j < NUM_COLS; j++) {
				board[i][j] = ""; 
				boxes[i][j].setIcon(new ImageIcon("blanksquare.png")); 
			}
		}
	}
	private void playSound(File file) {
	        try { 
	        	AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(file.getAbsoluteFile());
	        	Clip clip = AudioSystem.getClip();
	        	clip.open(audioInputStream);
	        	clip.start();
	        } catch (Exception e) {
	          System.err.println(e.getMessage());
	        }
	  }
	

	public JComponent getGUI() {
		  return panel; 
	  }
	
}

